# NIDDLE Android — Streaming MVP Starter

A Kotlin + Jetpack Compose Android starter with a black/red-pink visual theme, category/search UI, a Media3/ExoPlayer in-app player, share action, and a companion Node.js upload/catalogue API.

> This is a development starter, not a production-ready YouTube replacement. The app's current home catalogue is sample data; the companion API is a separate service and is **not yet wired into the Android UI**. The API stores catalogue metadata in a JSON file and uploaded files on local disk, suitable only for local testing. It is not a scalable production database or video CDN.

## Android app requirements
- Android Studio (current stable)
- JDK 17
- Android SDK 35
- Internet connection for Gradle dependencies and demo playback

## Build an APK
1. Extract `NIDDLE-Android-Starter.zip`.
2. Open the `NIDDLE-Android` folder in Android Studio.
3. Allow Gradle sync and install any SDK components Android Studio requests.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio displays a notification with **Locate**. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
6. For a release APK, use **Build → Generate Signed Bundle / APK…**, create/store a signing key securely, and select APK. Do not share your private keystore.

The APK has not been built or device-tested in this workspace. Fix any Gradle/SDK issues Android Studio reports before distribution.

## Run the API locally
Requires Node.js 20+.

```bash
cd backend
npm install
npm start
```

Health check: `http://localhost:8080/health`
List/search videos: `http://localhost:8080/api/videos` or `http://localhost:8080/api/videos?q=nature`
Upload with curl:

```bash
curl -X POST http://localhost:8080/api/videos \
  -F 'title=My first NIDDLE video' \
  -F 'creator=Sanjay' \
  -F 'category=Education' \
  -F 'description=My demo upload' \
  -F 'video=@/path/to/video.mp4;type=video/mp4'
```

Uploaded videos are written to `backend/uploads/`; metadata is in `backend/data/videos.json`. Back up these files if you need to retain test data.

### Connect Android emulator to local API
An Android emulator reaches the host computer at `http://10.0.2.2:8080`. A physical phone needs the computer's LAN IP and both devices on the same network. Android's cleartext HTTP policy may need explicit debug-only configuration for local testing. For any public release use HTTPS and a deployed server; do not expose a development server directly to the internet.

## Suggested production architecture
- **Android:** Kotlin, Jetpack Compose, Media3/ExoPlayer.
- **Authentication:** Firebase Authentication or an equivalent secure identity provider.
- **Database:** Firestore/PostgreSQL for user profiles, video metadata, subscriptions, likes, comments, playlists and moderation status.
- **Video storage and delivery:** object storage plus a video transcoding pipeline and CDN; use resumable uploads and adaptive HLS/DASH playback.
- **Authorized sources:** only embed or stream through a provider's official API/SDK when its terms permit it. Do not scrape or rehost YouTube videos or claim access to all internet videos.
- **Safety/operations:** verified ownership/permission, reporting and takedown flow, moderation, rate limits, upload quotas, malware/content checks, privacy policy, age-appropriate controls, analytics consent and backups.

## API outline
- `GET /health` — health check
- `GET /api/videos?q=&category=` — list/search catalogue
- `POST /api/videos` — multipart upload (`title`, `creator`, `category`, `description`, `video`)

The upload endpoint currently marks files `pending-review`, but it does not enforce user identity. **Do not deploy it publicly until authentication, authorization, persistent database storage, validation, moderation and HTTPS are implemented.**
