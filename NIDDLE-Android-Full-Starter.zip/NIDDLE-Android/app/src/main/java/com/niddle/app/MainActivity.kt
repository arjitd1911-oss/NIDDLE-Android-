package com.niddle.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF090B12)
private val Panel = Color(0xFF171B26)
private val Accent = Color(0xFFFF245C)
private val Muted = Color(0xFF9AA3B5)

 data class VideoItem(val title: String, val channel: String, val views: String, val category: String, val emoji: String, val url: String)

private val demoVideos = listOf(
    VideoItem("Big Buck Bunny — Sample Video", "NIDDLE Studio", "Sample video", "Nature", "🏔️", "https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"),
    VideoItem("Elephant Dream — Sample Film", "Blender Foundation", "Sample video", "Education", "📚", "https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4"),
    VideoItem("For Bigger Fun — Sample Clip", "NIDDLE Studio", "Sample video", "Gaming", "🎮", "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4"),
    VideoItem("For Bigger Joyrides — Sample Clip", "NIDDLE Studio", "Sample video", "Music", "🎵", "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4"),
    VideoItem("For Bigger Escapes — Sample Clip", "NIDDLE Studio", "Sample video", "Travel", "🌍", "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"),
    VideoItem("For Bigger Meltdowns — Sample Clip", "NIDDLE Studio", "Sample video", "Comedy", "😂", "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NiddleApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NiddleApp() {
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    var selectedTab by remember { mutableStateOf("Home") }
    var selectedVideo by remember { mutableStateOf<VideoItem?>(null) }
    var showUploadInfo by remember { mutableStateOf(false) }
    val categories = listOf("All", "Music", "Gaming", "Education", "Nature", "Travel", "Comedy")
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri != null) showUploadInfo = true
    }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Ink, surface = Panel)) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf("Home", "Shorts", "Upload", "Subscriptions", "Library").forEach { tab ->
                        val icon = when (tab) {
                            "Home" -> Icons.Default.Home
                            "Shorts" -> Icons.Default.Bolt
                            "Upload" -> Icons.Default.AddCircle
                            "Subscriptions" -> Icons.Default.Subscriptions
                            else -> Icons.Default.VideoLibrary
                        }
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = {
                                selectedTab = tab
                                if (tab == "Upload") picker.launch("video/*")
                                if (tab == "Shorts") category = "Comedy"
                            },
                            icon = { Icon(icon, contentDescription = tab) },
                            label = { Text(tab, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(selectedIconColor = Accent, indicatorColor = Accent.copy(alpha = .15f), selectedTextColor = Accent)
                        )
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                if (selectedVideo != null) {
                    VideoDetail(video = selectedVideo!!, onBack = { selectedVideo = null })
                } else {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Accent), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(29.dp))
                        }
                        Spacer(Modifier.width(9.dp))
                        Text("NIDDLE", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.weight(1f))
                        IconButton(onClick = { selectedTab = "Search" }) { Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White) }
                        Text("SK", modifier = Modifier.clip(CircleShape).background(Accent).padding(9.dp), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    OutlinedTextField(
                        value = query, onValueChange = { query = it },
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                        placeholder = { Text("Search videos, creators...", color = Muted) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Muted) },
                        singleLine = true, shape = RoundedCornerShape(16.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Accent, unfocusedBorderColor = Panel, focusedTextColor = Color.White, unfocusedTextColor = Color.White, cursorColor = Accent)
                    )
                    Spacer(Modifier.height(12.dp))
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        categories.forEach { item ->
                            FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Accent, selectedLabelColor = Color.White, labelColor = Color.White))
                        }
                    }
                    LazyColumn(contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 12.dp, bottom = 18.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                        item {
                            Box(Modifier.fillMaxWidth().height(155.dp).clip(RoundedCornerShape(20.dp)).background(brush = androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF45143B), Color(0xFF111827), Color(0xFF182E46)))).clickable { category = "All" }.padding(18.dp)) {
                                Column(Modifier.align(Alignment.CenterStart)) {
                                    Text("YOUR WORLD. YOUR VIDEOS.", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Spacer(Modifier.height(8.dp))
                                    Text("Watch. Explore. Enjoy.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                                    Text("Welcome to NIDDLE", color = Color(0xFFFFB6C9), fontSize = 13.sp)
                                }
                                Icon(Icons.Default.PlayCircle, contentDescription = null, tint = Accent, modifier = Modifier.align(Alignment.CenterEnd).size(54.dp))
                            }
                        }
                        item { Text(if (query.isBlank()) "Trending videos" else "Search results", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
                        val filtered = demoVideos.filter {
                            (category == "All" || it.category.equals(category, true)) &&
                            (query.isBlank() || it.title.contains(query, true) || it.channel.contains(query, true) || it.category.contains(query, true))
                        }
                        if (filtered.isEmpty()) item { Text("No demo videos found. Try another search.", color = Muted, modifier = Modifier.padding(12.dp)) }
                        items(filtered) { video -> VideoCard(video = video, onClick = { selectedVideo = video }) }
                        item {
                            Text("Demo catalogue", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                            Text("This starter app uses sample entries. Connect a backend and licensed video sources to publish a real catalogue.", color = Muted, fontSize = 12.sp, lineHeight = 17.sp)
                        }
                    }
                }
            }
        }
        if (showUploadInfo) {
            AlertDialog(onDismissRequest = { showUploadInfo = false }, title = { Text("Video selected") }, text = { Text("File picker works in this prototype, but publishing needs a server, sign-in, storage, and upload API. No video has been uploaded yet.") }, confirmButton = { TextButton(onClick = { showUploadInfo = false }) { Text("OK") } })
        }
    }
}

@Composable
fun VideoCard(video: VideoItem, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Box(Modifier.fillMaxWidth().height(190.dp).clip(RoundedCornerShape(18.dp)).background(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF26334D), Color(0xFF1A1427), Color(0xFF4A1D35)))), contentAlignment = Alignment.Center) {
            Text(video.emoji, fontSize = 55.sp)
            Icon(Icons.Default.PlayCircle, contentDescription = "Play video", tint = Color.White.copy(alpha = .92f), modifier = Modifier.align(Alignment.BottomEnd).padding(12.dp).size(35.dp))
            Text("NIDDLE", color = Color.White.copy(alpha = .75f), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.TopStart).padding(12.dp))
        }
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.Top) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(Accent.copy(alpha = .18f)), contentAlignment = Alignment.Center) { Text(video.emoji, fontSize = 20.sp) }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(video.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(4.dp))
                Text("${video.channel}  •  ${video.views}", color = Muted, fontSize = 12.sp)
            }
            Icon(Icons.Default.MoreVert, contentDescription = "More options", tint = Muted)
        }
    }
}

@Composable
fun VideoDetail(video: VideoItem, onBack: () -> Unit) {
    val context = LocalContext.current
    val player = remember(video.url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(video.url))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) {
        onDispose { player.release() }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White) }
            Text("NIDDLE Player", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        AndroidView(
            factory = { viewContext -> PlayerView(viewContext).apply { this.player = player; useController = true } },
            update = { it.player = player },
            modifier = Modifier.fillMaxWidth().height(235.dp).background(Color.Black)
        )
        Column(Modifier.padding(16.dp)) {
            Text(video.title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text("${video.channel}  •  ${video.views}", color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = {}, modifier = Modifier.weight(1f)) { Icon(Icons.Default.ThumbUp, contentDescription = null); Spacer(Modifier.width(5.dp)); Text("Like") }
                OutlinedButton(onClick = {
                    val sendIntent = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "Watch ${video.title} on NIDDLE: ${video.url}") }
                    context.startActivity(Intent.createChooser(sendIntent, "Share video"))
                }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Share, contentDescription = null); Spacer(Modifier.width(5.dp)); Text("Share") }
            }
            Spacer(Modifier.height(14.dp))
            Text("About this video", color = Color.White, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text("This build demonstrates in-app playback using sample public demo clips. Before launch, replace demo entries with videos you own, user-uploaded videos, or content you are licensed to distribute.", color = Muted, lineHeight = 20.sp)
        }
    }
}
