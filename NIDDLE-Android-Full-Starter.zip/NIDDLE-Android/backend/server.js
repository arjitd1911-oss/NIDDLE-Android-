const express = require('express');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = Number(process.env.PORT || 8080);
const DATA_DIR = path.join(__dirname, 'data');
const VIDEO_DIR = path.join(__dirname, 'uploads');
const CATALOG = path.join(DATA_DIR, 'videos.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(VIDEO_DIR, { recursive: true });
if (!fs.existsSync(CATALOG)) fs.writeFileSync(CATALOG, '[]');
app.use(cors()); // Restrict allowed origins before production deployment.
app.use(express.json({ limit: '1mb' }));
app.use('/media', express.static(VIDEO_DIR, { setHeaders(res) { res.setHeader('Accept-Ranges', 'bytes'); } }));

function readVideos() { return JSON.parse(fs.readFileSync(CATALOG, 'utf8')); }
function writeVideos(videos) { fs.writeFileSync(CATALOG, JSON.stringify(videos, null, 2)); }
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, VIDEO_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${crypto.randomBytes(8).toString('hex')}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 500 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const allowed = new Set(['video/mp4', 'video/webm', 'video/quicktime', 'video/x-matroska']);
    if (!allowed.has(file.mimetype)) return cb(new Error('Unsupported video type. Upload MP4, WebM, MOV or MKV.'));
    cb(null, true);
  }
});

app.get('/health', (_req, res) => res.json({ ok: true, service: 'NIDDLE API' }));
app.get('/api/videos', (req, res) => {
  const q = String(req.query.q || '').toLowerCase();
  const category = String(req.query.category || 'All');
  const videos = readVideos().filter(v => (!q || `${v.title} ${v.creator} ${v.category}`.toLowerCase().includes(q)) && (category === 'All' || v.category.toLowerCase() === category.toLowerCase()));
  res.json(videos);
});
// IMPORTANT: Add real authentication, authorization and moderation before public launch.
app.post('/api/videos', upload.single('video'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'Select a video file in field "video".' });
  const title = String(req.body.title || '').trim().slice(0, 120);
  if (!title) { fs.unlinkSync(req.file.path); return res.status(400).json({ error: 'Video title is required.' }); }
  const item = {
    id: crypto.randomUUID(), title,
    creator: String(req.body.creator || 'NIDDLE Creator').trim().slice(0, 80),
    category: String(req.body.category || 'Other').trim().slice(0, 40),
    description: String(req.body.description || '').trim().slice(0, 2000),
    url: `${req.protocol}://${req.get('host')}/media/${req.file.filename}`,
    filename: req.file.filename, sizeBytes: req.file.size,
    createdAt: new Date().toISOString(), source: 'user-upload', status: 'pending-review'
  };
  const videos = readVideos(); videos.unshift(item); writeVideos(videos);
  res.status(201).json({ message: 'Uploaded to the starter server. Review before publishing.', video: item });
});
app.use((err, _req, res, _next) => {
  if (err instanceof multer.MulterError) return res.status(400).json({ error: err.message });
  res.status(400).json({ error: err.message || 'Request failed' });
});
app.listen(PORT, '0.0.0.0', () => console.log(`NIDDLE API listening on ${PORT}`));
